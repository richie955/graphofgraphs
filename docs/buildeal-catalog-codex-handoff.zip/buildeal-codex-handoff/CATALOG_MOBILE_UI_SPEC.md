# Buildeal Admin — Catalog Hierarchy Mobile UI Implementation Specification

**Status:** Implementation handoff  
**Target:** Existing Buildeal Admin frontend, mobile-first at 320–430 px  
**Scope:** Category → Product Type → Canonical Product → Vendor Listings navigation and management  
**Design reference:** Accompanying screen screenshots from the ChatGPT mockups, numbered `01`–`10` if available. **The screenshots are the visual reference; this file is the behavioral/structural source of truth.**

## 0. Critical constraints

- Inspect the current app before editing. Use its router, layout, API client, query caching, auth/permission handling, design tokens, icon set, modal/sheet primitives, forms, and validation patterns.
- Do **not** invent endpoints, fields, approval transitions, destructive cascades, or routes. If a screen shows an illustrative field that is unsupported by the API, omit that field rather than simulate its functionality.
- This module is a **hierarchy explorer**, not a second implementation of the whole Products or Vendor Listings management modules. Link to existing canonical editor/details and listings views.
- Category, Product Type, Product, and Product Listing are **different entities**:
  - Category contains Product Types.
  - Product Type belongs to a Category.
  - Canonical Product belongs to a Product Type.
  - Product Listing associates a Vendor with a Product and has its own status, units, pricing/delivery logic.
- `product_count` and `vendor_listing_count` are different quantities; never substitute one for the other. Avoid N+1 count requests.
- Approval and activation are distinct. A pending/rejected record is not equivalent to an inactive record.
- Preserve desktop functionality; mobile **must not** use compressed desktop tables.
- Preserve current Buildeal Admin brand tokens; screenshot blue is illustrative. Do not replace established brand colors merely to match a draft.

## 1. Shared layout and visual contract

**Mobile viewport:** 320 / 360 / 375 / 390 / 430 px; no horizontal overflow.  
**Horizontal page padding:** ~16 px.  
**Spacing rhythm:** 4, 8, 12, 16, 24 px; avoid excessive nested cards.  
**Typography:** page title 22–24 px semibold; section title 16–18 px semibold; row title 14–15 px medium; metadata 12–13 px.  
**Control heights:** at least 40–44 px; interactive hit area at least 44×44 px.  
**List rows:** ~64–76 px height, one grouped list separated with thin neutral dividers.  
**Corners:** 8–12 px, no heavy shadows.  
**Colors:** use existing semantic tokens. Normal active = discreet dot + text; exceptional states = concise labeled indication.

- Preserve the global **Buildeal Admin / Administration** header and existing bottom navigation. Do not add another persistent navigation bar.
- Reserve adequate bottom padding above fixed navigation and respect safe-area insets.
- All nested views should be **contextual**: do not show the global `Categories` heading and `New category` button on product-type/product detail screens.
- One obvious primary action per screen section; avoid duplicate primary CTAs.
- Use a light parent/back link, not a large standalone Back button.
- Long names may wrap to two lines without hiding actions.

## 2. Primary screen flow (source of truth)

```text
Categories / category selected
   ├─ tap selected category → Select Category bottom sheet
   ├─ New → New Category form
   ├─ Add type → New Product Type form, category preselected
   └─ tap product type row → Product Type detail / canonical products
       ├─ parent back → prior category's product-type list
       ├─ type overflow → type action sheet
       ├─ Add product → EXISTING canonical product create flow, type preselected
       └─ tap product → EXISTING product detail view
           ├─ Details → canonical product information
           ├─ Vendor listings → associated listings
           ├─ Edit → EXISTING product edit flow
           └─ tap listing → EXISTING listing details (if available)
```

Navigation must support browser back/forward, direct refresh of supported nested routes, and preserving category selection and search/scroll when returning where practical. Prefer existing URL conventions and entity IDs; do not invent public routes just to satisfy this document.

## 3. Screen 01 — Categories / product types (default)

```text
┌────────────────────────────────────┐
│ ☰  Buildeal Admin                ↪ │ GLOBAL HEADER
│    Administration                  │
├────────────────────────────────────┤
│ Categories                 [+ New] │
│ Manage your catalog hierarchy      │
│                                    │
│ SELECTED CATEGORY                  │
│ ┌────────────────────────────────┐ │
│ │ ▣ Bricks & Blocks           ⌄ │ │ tap opens picker
│ │   10 product types             │ │
│ └────────────────────────────────┘ │
│                                    │
│ Product types   10    [+ Add type] │
│ ┌────────────────────────────────┐ │
│ │ ⌕ Search product types...      │ │
│ └────────────────────────────────┘ │
│  [All] [Active] [Inactive]         │
│                                    │
│ ▣ AAC Blocks                    › │
│   3 products · ● Active           │
│ ────────────────────────────────── │
│ ▣ Clay Bricks                   › │
│   6 products · ● Active           │
│ ────────────────────────────────── │
│ ▣ Concrete Blocks               › │
│   4 products · ● Active           │
│                                    │
│      [existing bottom nav]         │
└────────────────────────────────────┘
```

- Exactly **one** selected-category representation; do not repeat an image/header for the same category.
- Top-right `New` creates a **category**. `Add type` creates a **product type** under the selected category. Label them clearly in accessibility text.
- Product types are a **list**, not a multi-column table or grid.
- Row main tap navigates to products. A distinct overflow action may be shown where necessary; never make management and navigation the same tap target.
- Primary count below each type is number of canonical products; do not display UUID or repeated “Click to view products”.
- `All / Active / Inactive` filters **product types only**. If approval filtering already exists, include it in an advanced status control, not a huge chip row.
- Search within selected category; reset incompatible child filters when changing category.

## 4. Screen 02 — Select Category bottom sheet

```text
┌────────────────────────────────────┐
│              ━━━━━                 │
│ Select category                ×   │
│ ┌────────────────────────────────┐ │
│ │ ⌕ Search categories...         │ │
│ └────────────────────────────────┘ │
│ ▣ Bricks & Blocks              ✓   │
│   10 product types                 │
│ ────────────────────────────────── │
│ ▣ Cement                           │
│   5 product types                  │
│ ────────────────────────────────── │
│ ▣ Construction Chemicals           │
│   5 product types                  │
│ ... scroll                         │
│ ────────────────────────────────── │
│ + New category                     │
└────────────────────────────────────┘
```

- Searchable vertical list, selected row with restrained highlight + checkmark.
- Independent sheet scrolling, max-height fitting device, safe-area, accessible close/Escape/backdrop behavior; keyboard must not cover result rows.
- Selection closes sheet and updates category/type data without reloading page.
- Optional row-level menu to edit/manage a category, but primary row tap always **selects** it.

## 5. Screen 03 — Product Type detail / products

```text
┌────────────────────────────────────┐
│ ☰  Buildeal Admin                ↪ │
├────────────────────────────────────┤
│ ‹ Bricks & Blocks                  │ parent/back
│                                    │
│ AAC Blocks                      ···│ type actions
│ 3 products · 3 vendor listings     │
│                                    │
│ Products  3          [+ Add product]│
│ ┌────────────────────────────────┐ │
│ │ ⌕ Search products...           │ │
│ └────────────────────────────────┘ │
│                                    │
│ ▣ AAC Block 4 inch              › │
│   2 vendor listings · ● Active    │
│ ────────────────────────────────── │
│ ▣ AAC Block 6 inch              › │
│   1 vendor listing · ● Active     │
│ ────────────────────────────────── │
│ ▣ AAC Block 8 inch              › │
│   No vendor listings · ● Active   │
└────────────────────────────────────┘
```

- **Do not** display generic `Categories` page heading, `New category`, or oversized Back button here.
- Product type is the page identity; breadcrumbs/back show its parent category.
- Use correct aggregate counts; 0 listings are valid.
- Type menu controls the type. Product rows navigate to existing canonical product detail/editor.
- No duplicate new product editor. `Add product` reuses existing workflow with type prefilled.

## 6. Screen 04 — Canonical Product details

```text
┌────────────────────────────────────┐
│ ‹ AAC Blocks                   ··· │
│ ┌────────────────────────────────┐ │
│ │          [image]               │ │
│ └────────────────────────────────┘ │
│ AAC Block 4 inch                   │
│ ● Active · 2 vendor listings       │
│                                    │
│ [Details] [Vendor listings (2)]   │
│ ────────────────────────────────── │
│ Category          Bricks & Blocks  │
│ Product type      AAC Blocks       │
│ Brand             —                │
│ Attributes                          │
│   Thickness        4 inch          │
│   Material         AAC             │
│                                    │
│              [Edit product]        │
└────────────────────────────────────┘
```

- Prefer linking/reusing existing canonical product detail view rather than rebuilding it.
- Attribute labels/values above are **illustrative**, not guaranteed backend fields. Dynamically display supported product data.
- Maintain separation of canonical product data and vendor-specific pricing, units, and delivery.
- Image fallback should be understated; only show image if actually available.

## 7. Screen 05 — Product / vendor listings

```text
┌────────────────────────────────────┐
│ ‹ AAC Block 4 inch                 │
│ Vendor listings                    │
│ 2 listings                         │
│                                    │
│ [All] [Approved] [Pending]         │ only if supported
│                                    │
│ ABC BuildMart                    › │
│ Approved · Active                 │
│ (unit/price shown only if available)│
│ ────────────────────────────────── │
│ Prime Construction               › │
│ Approved · Active                 │
└────────────────────────────────────┘
```

- Reuse existing product listing association/detail view where present. A separate new screen is not required if the product's existing detail page has a tab.
- Actual pricing can vary by unit and quantity. Do **not** show a single misleading price for multi-unit listings. Prefer unit label, “From” price when correctly computed, or omit price.
- Read-only linked vendor listing information is acceptable. Do not duplicate the vendor listing editing workflow.

## 8. Screen 06 — Create / Edit Category

```text
┌────────────────────────────────────┐
│ ×         New category       Save │
├────────────────────────────────────┤
│ Category name *                    │
│ [e.g. Construction Chemicals     ]│
│                                    │
│ Category image                     │ only if API supports
│ ┌────────────────────────────────┐ │
│ │      Upload / preview          │ │
│ └────────────────────────────────┘ │
│ Description (optional)             │ only if supported
│ [                                ] │
│ [                                ] │
│                                    │
│ Active                          ○  │ only if editable
└────────────────────────────────────┘
```

- Full-screen sheet or dedicated mobile form; shared create/edit form with existing validation and API.
- Keep user-entered values after recoverable errors, show field/server errors, disable duplicate submissions, unsaved-change warning when appropriate.
- On successful creation, show/select new category; on edit, update selection without losing context.

## 9. Screen 07 — Create / Edit Product Type

```text
┌────────────────────────────────────┐
│ ×        New product type     Save │
├────────────────────────────────────┤
│ Category *                         │
│ [Bricks & Blocks               ⌄ ] │
│                                    │
│ Product type name *                │
│ [e.g. AAC Blocks                 ] │
│                                    │
│ Description (optional)             │ only if supported
│ [                                ] │
│                                    │
│ Active                          ○  │ only if editable
└────────────────────────────────────┘
```

- Prefill selected category; respect uniqueness and category-change restrictions.
- Preserve backend approval workflow; admin activation != approval.
- If a field shown is unsupported, remove it; do not add speculative schema changes just for wireframe fidelity.

## 10. Screen 08 — Contextual actions sheet

```text
┌────────────────────────────────────┐
│              ━━━━━                 │
│ AAC Blocks                     ×   │
│ Product type actions               │
│ ────────────────────────────────── │
│ ✎ Edit product type                │
│ ○ Deactivate                       │
│ ♧ Delete product type              │ destructive color
└────────────────────────────────────┘
```

- Use existing action/permission logic. Type action menu is not a product action menu.
- Category action menu and Product action menu should follow the same visual pattern, with entity-specific actions only.
- Inactive entity should show `Activate`, not `Deactivate`.

## 11. Screen 09 — Destructive confirmation

```text
┌────────────────────────────────────┐
│ Delete product type?               │
│ You are about to delete AAC Blocks.│
│ Dependent products may prevent it. │
│                                    │
│ [Cancel]                [Delete]   │
└────────────────────────────────────┘
```

- Explain only **known** consequences. Do not promise cascade deletion.
- Respect backend soft-delete/dependency rejection and show actual failure reason.
- Confirm destructive actions; deactivation confirmations should follow app patterns.

## 12. Screen 10 — Empty, loading, error and search states

- No categories: `No categories yet` + `New category`.
- No product types: `No product types yet` + `Add product type`.
- No products: `No products yet` + `Add product`.
- Search no matches: `No matching results` + `Clear search`.
- Filter no matches: show active scope/filter + reset option.
- No vendor listings: canonical product still valid, show `No vendor listings`.
- Loading: skeleton list rows, keep header/selected parent visible.
- Error: compact explanation + retry; do not show misleading empty state while loading/failing.
- Unauthorized / deleted direct link: preserve navigation escape to parent and show appropriate feedback.

## 13. Interaction contract

| Interaction | Result | Must not happen |
|---|---|---|
| Tap category selector | Open category picker | Duplicate expanded category grid on page |
| Tap category picker row | Select category, close sheet, load types | Open edit form |
| Tap Product Type list row | Go to its canonical products | Open edit form, expand inline |
| Tap Product Type `···` | Open type action menu | Trigger row navigation |
| Tap Product row | Open canonical product details | Open vendor listing editor |
| Tap vendor listing | Open existing vendor listing detail, if present | Pretend product and listing are same entity |
| Back from product | Return to product-type products | Lose selected type |
| Back from type | Return to selected category's types | Return to generic Dashboard |
| Add product | Existing product create flow, preselected type | Duplicate product editor |
| Switch category | Reset incompatible child selection | Keep stale products from old type |

## 14. Engineering integration requirements

- Search repository for existing category/type/product CRUD code and data models. Refactor presentation, not core business logic.
- Use existing queries and cache invalidation; optimistic updates only where supported and safe.
- Use abort/identity guarding to prevent stale fetches rendering wrong category/type after quick selection changes.
- Do not perform one API request per product-type row merely to compute counts.
- Use the existing global admin responsive layout and bottom nav; prevent overlay/scroll-lock bugs on mobile.
- Use correct semantic interactive elements, focus management, keyboard escape, accessible labels and 44 px touch targets.
- At desktop, keep or improve the master-detail sidebar/table layout; do not apply mobile card pattern indiscriminately.
- Test flows on actual running app, ideally with a browser/screenshot capability. Compare real captures to references for spacing and hierarchy, not just code aesthetics.

## 15. Implementation & validation checklist

- [ ] Desktop existing flows are not broken.
- [ ] At 320 / 360 / 375 / 390 / 430 px, no horizontal scrolling or overlap.
- [ ] Main screen has exactly one selected-category control.
- [ ] Mobile product types and products are **flat lists**, not tables.
- [ ] No generic Categories header / New action on nested drill-down screen.
- [ ] Product type row tap navigates, overflow menu only manages.
- [ ] Counts correctly distinguish canonical products from vendor listings.
- [ ] Status semantics remain accurate; pending/rejected != inactive.
- [ ] Existing create/edit product route reused with correct type context.
- [ ] Picker search, selection, scroll, dismissal, keyboard behavior work.
- [ ] Back/forward + refresh of supported nested routes work.
- [ ] Empty, loading, search-empty, error and unauthorized states work.
- [ ] CRUD, validation, permissions, dependency restrictions are preserved.
- [ ] No fake screens, hard-coded demonstration product data, or invented endpoints.
- [ ] Lint, typecheck and relevant test/build commands run; failures reported accurately.
- [ ] Mobile screenshots from implementation have been compared against reference screenshots.

## 16. Example data is NOT production data

Names such as AAC Blocks / AAC Block 4 inch and counts shown in the wireframes are only to illustrate the visual hierarchy. Use real API data. Screenshots are not a license to hardcode fixtures into the production frontend.

## 17. Definition of done

A mobile user can select a category, find a type, open its canonical products, open a product, inspect linked vendor listings, and use available create/edit/deactivate/delete workflows without confusing entities, losing context, encountering a compressed desktop table, or needing to scroll through an enormous category grid. Visuals must closely resemble the supplied references while preserving project conventions and existing behavior.
