# Paste this task into Codex (from the repository root)

Implement the complete Buildeal Admin mobile Catalog hierarchy UI from `docs/catalog/CATALOG_MOBILE_UI_SPEC.md` and the `docs/catalog/references/` screenshots.

Treat the screenshots as **visual references**, and the Markdown spec as the **screen-by-screen behavioral contract**. The actual repository models, route contracts, permission checks, and API fields are authoritative; do not invent unsupported functionality just to resemble a mockup.

**Instructions:**

1. Inspect the current code: admin layout, mobile bottom navigation, catalog categories, product types, products, vendor listings, CRUD forms, route/query state, hooks, design tokens, reusable sheets and menus. Identify reusable parts before editing.
2. Implement the mobile screens and interactions described in the spec, including category picker, type list, type→products drill-down, product detail/listings navigation, create/edit flows, actions, confirmation, and all empty/loading/error states. Reuse existing canonical product and listing editors rather than duplicating them.
3. Maintain existing desktop behavior and backend semantics. Mobile gets proper list layouts, not compressed tables. Preserve native back/forward and selected-category context.
4. Use screenshot references to match hierarchy, density, spacing, typography, controls, and placement. **Do not implement screenshots as giant static images** and do not hardcode mock records.
5. Run the project and capture mobile screenshots at widths 375 and 390 px for main screen, picker, product-type detail, and product detail, using existing browser/testing tools if available. Compare to references and refine. Also check 320 and 430 px, plus desktop regression.
6. Run available lint, typecheck, build, and relevant tests. Fix discovered issues. Do not declare unrun checks passed.
7. In your final report, list modified files, reused APIs/components, implemented screens, test commands/results, screenshots or visual-verification limitations, and any backend gaps.

Do the implementation now. Do not stop at a plan or a prose description. If an existing backend limitation blocks a particular optional action, preserve correct functionality and clearly report that limitation rather than inventing an API.
