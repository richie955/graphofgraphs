# How to give this handoff to Codex

1. In your frontend repository create `docs/catalog/` and `docs/catalog/references/`.
2. Copy `CATALOG_MOBILE_UI_SPEC.md` to `docs/catalog/CATALOG_MOBILE_UI_SPEC.md`.
3. Save screenshots of the in-chat wireframes under `docs/catalog/references/` (e.g., `01-categories.png`, `02-picker.png`, `03-product-type-products.png`, `04-product-details.png`, `05-listings.png`, `06-category-form.png`, `07-type-form.png`, `08-actions.png`, `09-delete.png`, `10-empty-states.png`). These are intentionally not included in this handoff since the in-chat UI is not an accessible code asset.
4. Open Codex in the repository and paste the contents of `CODEX_START_HERE.md`.
5. Review the running UI at 390 px and send Codex screenshots of deviations to fix one screen at a time.

Important: UI mockups rendered directly in chat do not automatically become frontend components or source code in your repository. The reference screenshots and spec communicate design intent, not executable code.
